from math import *
import os
import time
import platform
import RPi.GPIO as GPIO

pos = [0, 0]
vel = [0, 0]
rot = 0
unit = 0
run = True
path = []
base_pos = []
checkpoint_pos = []
entree=""
oses_clear = {"Windows": "cls", "Linux": "clear"}
oses = platform.system()

def set_pins():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(4, GPIO.OUT)
    GPIO.setup(17, GPIO.OUT)
    GPIO.output(4, GPIO.HIGH)
    GPIO.output(17, GPIO.HIGH)

def set_base():
    global pos, rot
    pos=[0, 0]
    rot = 0

def set_checkpoint():
    global pos, checkpoint_pos
    checkpoint_pos = pos

def draw_options():
    print("Z pour avancer")
    print("S pour reculer")
    print("R pour revenir à la base")
    print("C pour l'emplacement de rangement")
    print("B pour replacer la base à la position actuelle")
    print("exit pour quitter proprement")

def save_point(point: list):
    global path
    path.append(point)

def get_rad_angle(angle):
    global rot_rad
    rot_rad = angle * (pi/180)
    return rot_rad

def create_velocity(unit, angle):
    global vel
    vel[0] = unit * cos(angle)
    vel[1] = unit * cos(angle)

def apply_vel_to_pos(vel: list):
    global pos
    pos[0] += vel[0]
    pos[1] += vel[1]

def process_input():
    global rot, vel, pos, run
    entree = str(input("Choix: "))
    unit = 0
    if entree == "z" or entree == "Z":
        unit = 10
        rot_rad = get_rad_angle(rot)
        create_velocity(unit, rot_rad)
        apply_vel_to_pos(vel)
        save_point(pos)
        GPIO.output(4, GPIO.LOW)
        time.sleep(2)
        GPIO.output(4, GPIO.HIGH)
    elif entree == "s" or entree == "S":
        unit = -10
        rot_rad = get_rad_angle(rot)
        create_velocity(unit, rot_rad)
        apply_vel_to_pos(vel)
        save_point(pos)
        GPIO.output(17, GPIO.LOW)
        time.sleep(2)
        GPIO.output(17, GPIO.HIGH)
    elif entree == "c" or entree == "C":
        choice = input("Etes vous sûr de mettre le checkpoint ici ? ")
        if choice == "o" or choice == "O":
            set_checkpoint()
            print("Checkpoint défini !")
            time.sleep(1)
        else:
            print("Annulé !")
            time.sleep(1)
    elif entree == "b" or entree == "B":
        choice = input("Etes vous sûr de réinitialiser la base ? ")
        if choice == "o" or choice == "O":
            set_base()
            print("Base réinitialisée !")
            time.sleep(1)
        else:
            print("Annulé !")
            time.sleep(1)

    elif entree == "exit":
        run = False

set_pins()
while run:
    os.system(oses_clear[oses])
    draw_options()
    process_input()
    time.sleep(0.064)

print("Programme arreté")

GPIO.cleanup()
