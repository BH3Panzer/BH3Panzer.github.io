from setuptools import setup
from Cython.Build import cythonize

setup(
    ext_modules=cythonize("texture_generator.pyx", nthreads=4)
)

setup(
    ext_modules=cythonize("universe_generator.pyx", nthreads=4)
)

setup(
    ext_modules=cythonize("galaxy_generator.pyx", nthreads=4)
)

setup(
    ext_modules=cythonize("handler_engine.pyx", nthreads=4)
)

setup(
    ext_modules=cythonize("player_handler.pyx", nthreads=4)
)